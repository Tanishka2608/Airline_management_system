import mysql.connector

def get_db_connection():
    try:
        conn = mysql.connector.connect(
            host="localhost",      # XAMPP runs MySQL locally
            user="root",           # default XAMPP user
            password="",           # leave empty unless you set a password in phpMyAdmin
            database="airlines"    # the DB name we created
        )
        return conn
    except mysql.connector.Error as err:
        print(f"Database connection error: {err}")
        return None
