<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Smart Airlines - Staff</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
  <style>
    /* Add modal & table styling */
    .modal {display:none;position:fixed;z-index:1000;left:0;top:0;width:100%;height:100%;background:rgba(0,0,0,0.5);justify-content:center;align-items:center;}
    .modal-content{background:#fff;padding:25px;border-radius:12px;width:400px;max-width:90%;position:relative;box-shadow:0 5px 25px rgba(0,0,0,0.3);}
    .modal-content h2{margin-bottom:15px;color:#007bff;text-align:center;}
    .close-btn{position:absolute;top:10px;right:15px;font-size:22px;font-weight:bold;color:#333;cursor:pointer;}
    .close-btn:hover{color:red;}
    .action-btn{padding:8px 12px;border:none;border-radius:6px;cursor:pointer;font-weight:600;font-size:0.9em;transition:0.3s;margin:0 3px;}
    .edit-btn{background:#4caf50;color:white;text-decoration:none;padding:5px 10px;}
    .delete-btn{background:#f44336;color:white;text-decoration:none;padding:5px 10px;}
    table th, table td{padding:12px;text-align:center;}
    table th{background:#004aad;color:#fff;}
    table tr:nth-child(even){background:#f2f6ff;}
  </style>
</head>
<body>
  <header>
    <div class="logo">✈ Smart Airlines</div>
    <nav>
      <a href="/" >Home</a>
      <a href="/booking" >Book Flight</a>
      <a href="/dashboard" >Dashboard</a>
      <a href="/staff" class="active">Staff</a>
    </nav>
  </header>

  <div class="container">
    <h1>Staff Management</h1>

    <!-- Add Staff Form -->
    <div class="card">
      <h2>Add New Staff</h2>
      <form method="POST" action="/staff">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="text" name="role" placeholder="Role" required>
        <input type="tel" name="contact" placeholder="Contact Number" required>
        <button type="submit">Add Staff</button>
      </form>
    </div>

    <!-- Staff Table -->
    <div class="card">
      <h2>Staff List</h2>
      <table>
        <thead>
          <tr>
            <th>Staff ID</th>
            <th>Name</th>
            <th>Role</th>
            <th>Contact</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {% for s in staff_list %}
          <tr>
            <td>S{{ "%03d"|format(s[0]) }}</td>
            <td>{{ s[1] }}</td>
            <td>{{ s[2] }}</td>
            <td>{{ s[3] }}</td>
            <td>
              <a href="/edit/{{ s[0] }}" class="action-btn edit-btn">✎ Edit</a>
              <a href="/delete/{{ s[0] }}" class="action-btn delete-btn">🗑 Delete</a>
            </td>
          </tr>
          {% endfor %}
        </tbody>
      </table>
    </div>
  </div>

  {% if edit_staff %}
  <!-- Edit Modal -->
  <div class="modal" style="display:flex;">
    <div class="modal-content">
      <span class="close-btn" onclick="window.location='/staff'">&times;</span>
      <h2>Edit Staff</h2>
      <form method="POST" action="/edit/{{ edit_staff[0] }}">
        <input type="text" name="name" value="{{ edit_staff[1] }}" required>
        <input type="text" name="role" value="{{ edit_staff[2] }}" required>
        <input type="tel" name="contact" value="{{ edit_staff[3] }}" required>
        <button type="submit">Update Staff</button>
      </form>
    </div>
  </div>
  {% endif %}

  <footer>
    <p>© 2025 Smart Airlines | Staff Management</p>
  </footer>
</body>
</html>
