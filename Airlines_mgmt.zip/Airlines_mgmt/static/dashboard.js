// Monthly Bookings Chart
new Chart(document.getElementById("bookingsChart"), {
  type: "bar",
  data: {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"],
    datasets: [{
      label: "Bookings",
      data: [120, 190, 300, 250, 320, 400, 380],
      backgroundColor: "#0052d4"
    }]
  },
  options: { responsive: true }
});

// Revenue Chart
new Chart(document.getElementById("revenueChart"), {
  type: "line",
  data: {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"],
    datasets: [{
      label: "Revenue ($K)",
      data: [50, 80, 120, 100, 150, 200, 180],
      borderColor: "#6fb1fc",
      backgroundColor: "rgba(111,177,252,0.2)",
      fill: true,
      tension: 0.4
    }]
  },
  options: { responsive: true }
});

// Flight Delay Pie Chart
new Chart(document.getElementById("delayChart"), {
  type: "pie",
  data: {
    labels: ["On-Time", "Delayed", "Cancelled"],
    datasets: [{
      data: [70, 20, 10],
      backgroundColor: ["#28a745", "#ffc107", "#dc3545"]
    }]
  },
  options: { responsive: true }
});

// Popular Routes Doughnut
new Chart(document.getElementById("routesChart"), {
  type: "doughnut",
  data: {
    labels: ["NYC → London", "Delhi → Dubai", "Tokyo → LA", "Paris → Rome"],
    datasets: [{
      data: [300, 250, 180, 120],
      backgroundColor: ["#0052d4", "#4364f7", "#6fb1fc", "#00c6ff"]
    }]
  },
  options: { responsive: true }
});
