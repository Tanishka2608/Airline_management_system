<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Smart Airlines - Passengers</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background: #f5f9ff;
      color: #333;
    }
    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 50px;
      background: linear-gradient(90deg, #004aad, #007bff);
      color: #fff;
      box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    }
    .logo { font-size: 1.6em; font-weight: 700; }
    nav a {
      margin-left: 20px; color: #fff;
      text-decoration: none; font-weight: 500;
      transition: color 0.3s;
    }
    nav a:hover, nav a.active { color: #ffd700; }
    .container { max-width: 1200px; margin: 30px auto; padding: 0 20px; }
    h1 { text-align: center; color: #004aad; margin-bottom: 25px; }
    .card {
      background: #fff; border-radius: 15px; padding: 25px;
      margin-bottom: 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }
    .card h2 { color: #007bff; margin-bottom: 15px; }
    form {
      display: grid; grid-template-columns: 1fr 1fr; gap: 15px;
    }
    form input, form select, form button {
      padding: 12px; border-radius: 8px; border: 1px solid #ccc; font-size: 1em;
    }
    form button {
      grid-column: span 2; background: #ff9800; color: #fff; border: none;
      cursor: pointer; font-weight: 600; transition: 0.3s;
    }
    form button:hover { background: #e67e00; }
    table {
      width: 100%; border-collapse: collapse; background: #fff;
      border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }
    table th, table td { padding: 15px; text-align: center; }
    table th { background: #004aad; color: #fff; }
    table tr:nth-child(even) { background: #f2f6ff; }
    .action-btn {
      padding: 8px 12px; border: none; border-radius: 6px; cursor: pointer;
      font-weight: 600; font-size: 0.9em; transition: 0.3s; margin: 0 3px;
    }
    .edit-btn { background: #4caf50; color: white; }
    .edit-btn:hover { background: #3d8b40; }
    .delete-btn { background: #f44336; color: white; }
    .delete-btn:hover { background: #d32f2f; }
    footer {
      background: #004aad; color: #fff; text-align: center;
      padding: 20px; margin-top: 40px;
    }
    /* Modal Styling */
    .modal {
      display: none; position: fixed; z-index: 1000; left: 0; top: 0;
      width: 100%; height: 100%; background: rgba(0,0,0,0.5);
      display: flex; justify-content: center; align-items: center;
    }
    .modal-content {
      background: #fff; padding: 25px; border-radius: 12px;
      width: 400px; max-width: 90%; position: relative;
      box-shadow: 0 5px 25px rgba(0,0,0,0.3);
    }
    .modal-content h2 { margin-bottom: 15px; color: #007bff; text-align: center; }
    .modal-content form { grid-template-columns: 1fr; }
    .close-btn {
      position: absolute; top: 10px; right: 15px; font-size: 22px;
      font-weight: bold; color: #333; cursor: pointer;
    }
    .close-btn:hover { color: red; }
  </style>
</head>
<body>
  <header>
    <div class="logo">✈ Smart Airlines</div>
    <nav>
      <a href="/">Home</a>
      <a href="/booking">Book Flight</a>
      <a href="/dashboard">Dashboard</a>
      <a href="/passengers" class="active">Passengers</a>
    </nav>
  </header>

  <div class="container">
    <h1>Passenger Management</h1>

    <!-- Add Passenger Form -->
    <div class="card">
      <h2>Add New Passenger</h2>
      <form id="addForm">
        <input type="text" id="add_name" placeholder="Full Name" required>
        <input type="text" id="add_passport" placeholder="Passport Number" required>
        <input type="email" id="add_email" placeholder="Email Address" required>
        <input type="tel" id="add_phone" placeholder="Phone Number" required>
        <select id="add_gender" required>
          <option value="">Select Gender</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
          <option value="other">Other</option>
        </select>
        <input type="text" id="add_nationality" placeholder="Nationality" required>
        <button type="submit">Add Passenger</button>
      </form>
    </div>

    <!-- Passenger List -->
    <div class="card">
      <h2>Passenger List</h2>
      <table>
        <thead>
          <tr>
            <th>Passenger ID</th>
            <th>Name</th>
            <th>Passport No.</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Nationality</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="passengerTable">
          <tr>
            <td>P001</td>
            <td>Rahul Sharma</td>
            <td>A123456</td>
            <td>rahul@mail.com</td>
            <td>9876543210</td>
            <td>Indian</td>
            <td>
              <button class="action-btn edit-btn" onclick="openModal('P001','Rahul Sharma','A123456','rahul@mail.com','9876543210','Indian')">✎ Edit</button>
              <button class="action-btn delete-btn">🗑 Delete</button>
            </td>
          </tr>
          <tr>
            <td>P002</td>
            <td>Sara Khan</td>
            <td>B789101</td>
            <td>sara@mail.com</td>
            <td>9123456780</td>
            <td>Indian</td>
            <td>
              <button class="action-btn edit-btn" onclick="openModal('P002','Sara Khan','B789101','sara@mail.com','9123456780','Indian')">✎ Edit</button>
              <button class="action-btn delete-btn">🗑 Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Edit Modal -->
  <div id="editModal" class="modal">
    <div class="modal-content">
      <span class="close-btn" onclick="closeModal()">&times;</span>
      <h2>Edit Passenger</h2>
      <form id="editForm">
        <input type="hidden" id="edit_id">
        <input type="text" id="edit_name" placeholder="Full Name" required>
        <input type="text" id="edit_passport" placeholder="Passport Number" required>
        <input type="email" id="edit_email" placeholder="Email Address" required>
        <input type="tel" id="edit_phone" placeholder="Phone Number" required>
        <input type="text" id="edit_nationality" placeholder="Nationality" required>
        <button type="submit">Update Passenger</button>
      </form>
    </div>
  </div>

  <footer>
    <p>© 2025 Smart Airlines | Passenger Management</p>
  </footer>

  <script>
    const modal = document.getElementById("editModal");
    const tableBody = document.getElementById("passengerTable");
    let passengerCount = 2; // Existing passengers

    // Open modal and fill data
    function openModal(id, name, passport, email, phone, nationality) {
      document.getElementById("edit_id").value = id;
      document.getElementById("edit_name").value = name;
      document.getElementById("edit_passport").value = passport;
      document.getElementById("edit_email").value = email;
      document.getElementById("edit_phone").value = phone;
      document.getElementById("edit_nationality").value = nationality;
      modal.style.display = "flex";
    }

    // Close modal
    function closeModal() {
      modal.style.display = "none";
    }

    window.onclick = function(event) {
      if (event.target == modal) {
        closeModal();
      }
    }

    // Edit form submission
    document.getElementById("editForm").addEventListener("submit", function(e) {
      e.preventDefault();
      const id = document.getElementById("edit_id").value;
      const name = document.getElementById("edit_name").value;
      const passport = document.getElementById("edit_passport").value;
      const email = document.getElementById("edit_email").value;
      const phone = document.getElementById("edit_phone").value;
      const nationality = document.getElementById("edit_nationality").value;

      // Update the table row
      const rows = tableBody.querySelectorAll("tr");
      rows.forEach(row => {
        if(row.children[0].textContent === id) {
          row.children[1].textContent = name;
          row.children[2].textContent = passport;
          row.children[3].textContent = email;
          row.children[4].textContent = phone;
          row.children[5].textContent = nationality;
        }
      });

      alert(`Passenger ${id} updated successfully!`);
      closeModal();
    });

    // Delete confirmation
    function attachDelete() {
      const deleteButtons = document.querySelectorAll('.delete-btn');
      deleteButtons.forEach(btn => {
        btn.onclick = function() {
          const row = this.closest('tr');
          const passengerName = row.children[1].textContent;
          if (confirm(`Are you sure you want to delete passenger "${passengerName}"?`)) {
            row.remove();
            alert(`Passenger "${passengerName}" deleted successfully!`);
          }
        }
      });
    }

    attachDelete(); // Attach to initial rows

    // Add new passenger
    document.getElementById("addForm").addEventListener("submit", function(e) {
      e.preventDefault();
      passengerCount++;
      const name = document.getElementById("add_name").value;
      const passport = document.getElementById("add_passport").value;
      const email = document.getElementById("add_email").value;
      const phone = document.getElementById("add_phone").value;
      const gender = document.getElementById("add_gender").value;
      const nationality = document.getElementById("add_nationality").value;
      const id = "P" + passengerCount.toString().padStart(3,"0");

      const newRow = document.createElement("tr");
      newRow.innerHTML = `
        <td>${id}</td>
        <td>${name}</td>
        <td>${passport}</td>
        <td>${email}</td>
        <td>${phone}</td>
        <td>${nationality}</td>
        <td>
          <button class="action-btn edit-btn" onclick="openModal('${id}','${name}','${passport}','${email}','${phone}','${nationality}')">✎ Edit</button>
          <button class="action-btn delete-btn">🗑 Delete</button>
        </td>
      `;
      tableBody.appendChild(newRow);
      attachDelete(); // Re-attach delete to new row
      alert(`Passenger ${id} added successfully!`);
      this.reset();
    });
  </script>
</body>
</html>
