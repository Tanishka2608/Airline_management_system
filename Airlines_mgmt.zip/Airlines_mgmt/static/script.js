// Handle Flight Search
document.getElementById("searchForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const source = document.getElementById("source").value;
  const destination = document.getElementById("destination").value;
  const date = document.getElementById("date").value;

  document.getElementById("results").innerHTML = `
    <div class="card">
      <h3>Available Flights</h3>
      <p>From <b>${source}</b> to <b>${destination}</b> on <b>${date}</b>.</p>
      <ul>
        <li>✈ Flight A123 - 9:00 AM - $300</li>
        <li>✈ Flight B456 - 2:00 PM - $250</li>
        <li>✈ Flight C789 - 6:00 PM - $280</li>
      </ul>
    </div>`;
});

// Handle AI Price Prediction
document.getElementById("predictForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const source = document.getElementById("p_source").value;
  const destination = document.getElementById("p_destination").value;
  const days = document.getElementById("days_before").value;

  const predictedPrice = Math.floor(Math.random() * (500 - 200 + 1)) + 200;

  document.getElementById("predicted").textContent =
    `Predicted price from ${source} to ${destination}, if booked ${days} days before: $${predictedPrice}`;
});
