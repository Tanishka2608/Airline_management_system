from flask import Flask, render_template, request, redirect, url_for, session, flash
import pickle
import numpy as np
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import traceback
import os

app = Flask(__name__)
app.secret_key = "smartair_secret_key"

# ---------------- Demo Mode ----------------
db_enabled = False  # When True, connect to MySQL
staff_data = [
    {"id": 1, "name": "John Doe", "role": "Pilot", "contact": "9998887777"},
    {"id": 2, "name": "Jane Smith", "role": "Cabin Crew", "contact": "8887776666"}
]
passengers_data = [
    {"id": 1, "name": "Alice Brown", "flight": "AI203", "seat": "12A"},
    {"id": 2, "name": "Bob Green", "flight": "BA110", "seat": "22C"}
]
next_staff_id = 3
next_passenger_id = 3

# ---------------- AI Model ----------------
price_model = None
MODEL_PATH = "price_model.pkl"
if os.path.exists(MODEL_PATH):
    try:
        with open(MODEL_PATH, "rb") as f:
            price_model = pickle.load(f)
    except Exception as e:
        # If unpickling fails we'll keep price_model = None and fallback to rule-based pricing
        price_model = None
        app.logger.warning("Could not load price_model.pkl — falling back to rule-based. Error: %s", e)


@app.route("/")
def index():
    return render_template("index.html")


# -------- Signup --------
@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        flash("Database not connected — signup disabled in demo mode.", "warning")
        return redirect(url_for("login"))
    return render_template("signup.html")


# -------- Login --------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "Guest")
        session["user"] = username
        flash("Demo login successful!", "success")
        return redirect(url_for("dashboard"))
    return render_template("login.html")


# -------- Logout --------
@app.route("/logout")
def logout():
    session.pop("user", None)
    flash("Logged out successfully.", "info")
    return redirect(url_for("index"))


# -------- Dashboard --------
@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        flash("Please login first.", "warning")
        return redirect(url_for("login"))
    return render_template("dashboard.html", user=session["user"], datetime=datetime)


# -------- Staff --------
@app.route("/staff", methods=["GET", "POST"])
def staff():
    global next_staff_id
    if "user" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        name = request.form["name"]
        role = request.form["role"]
        contact = request.form["contact"]
        new_staff = {"id": next_staff_id, "name": name, "role": role, "contact": contact}
        staff_data.append(new_staff)
        next_staff_id += 1
        flash("Staff added successfully!", "success")

    return render_template("staff.html", staff=staff_data, datetime=datetime)


@app.route("/delete_staff/<int:id>")
def delete_staff(id):
    global staff_data
    staff_data = [s for s in staff_data if s["id"] != id]
    flash("Staff deleted successfully!", "info")
    return redirect(url_for("staff"))


# -------- Passengers --------
@app.route("/passengers", methods=["GET", "POST"])
def passengers():
    global next_passenger_id
    if "user" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        name = request.form["name"]
        flight = request.form["flight"]
        seat = request.form["seat"]
        new_passenger = {"id": next_passenger_id, "name": name, "flight": flight, "seat": seat}
        passengers_data.append(new_passenger)
        next_passenger_id += 1
        flash("Passenger added successfully!", "success")

    return render_template("passengers.html", passengers=passengers_data, datetime=datetime)


@app.route("/delete_passenger/<int:id>")
def delete_passenger(id):
    global passengers_data
    passengers_data = [p for p in passengers_data if p["id"] != id]
    flash("Passenger deleted successfully!", "info")
    return redirect(url_for("passengers"))


# -------- Booking --------
# Global booking data for demo mode
booked_seats = ["A1", "B3", "E5"]  # optional pre-booked seats
booking_data = []


@app.route("/booking", methods=["GET", "POST"])
def booking():
    global next_passenger_id, passengers_data, booked_seats, booking_data

    if "user" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        passenger = request.form["passenger"]
        flight_no = request.form["flight_no"]
        seat = request.form["seat"]
        date = request.form["date"]
        class_type = request.form["class"]

        # Prevent duplicate seat booking
        if seat in booked_seats:
            flash(f"Seat {seat} is already booked! Please choose another seat.", "danger")
        else:
            booked_seats.append(seat)
            booking_data.append({
                "passenger": passenger,
                "flight_no": flight_no,
                "seat": seat,
                "date": date,
                "class": class_type
            })

            # Auto-add passenger (demo mode)
            new_passenger = {"id": next_passenger_id, "name": passenger, "flight": flight_no, "seat": seat}
            passengers_data.append(new_passenger)
            next_passenger_id += 1

            flash(f"Booking confirmed for {passenger} — Seat {seat}", "success")

    return render_template("booking.html", bookings=booking_data, booked_seats=booked_seats, datetime=datetime)


# -------- Price Prediction --------
@app.route("/price", methods=["GET", "POST"])
def price():
    if "user" not in session:
        return redirect(url_for("login"))

    predicted_price = None
    flight_info = None

    if request.method == "POST":
        try:
            airline = request.form.get("airline", "").strip()
            source = request.form.get("source", "").strip()
            destination = request.form.get("destination", "").strip()
            duration = float(request.form.get("duration", 0))
            stops = int(request.form.get("stops", 0))
            seat_class = request.form.get("class", "Economy")
            date = request.form.get("date", "")

            # Try to predict with the model if available
            if price_model is not None:
                try:
                    # NOTE: This assumes your model expects [duration, stops] — adjust if your model needs other features.
                    features = np.array([[duration, stops]])
                    predicted_price = round(float(price_model.predict(features)[0]), 2)
                except Exception as e:
                    # If prediction fails, log and fallback to rule-based
                    app.logger.warning("Model prediction failed, falling back to rule-based. Error: %s", e)
                    predicted_price = None

            # Fallback deterministic rule-based calculation
            if predicted_price is None:
                # Basic rule-based pricing: base + duration*factor - stops*penalty, class multiplier
                base = 2500 + (duration * 400) - (stops * 150)
                if seat_class == "Business":
                    base *= 1.5
                elif seat_class == "First Class":
                    base *= 2.0

                # small random-ish deterministic adjustment to avoid flat numbers (use hash)
                adjustment = (abs(hash(f"{airline}{source}{destination}{date}")) % 500) - 250
                predicted_price = round(max(500, base + adjustment), 2)

            # Build flight_info with all fields expected by your templates
            flight_info = {
                "airline": airline,
                "source": source,
                "destination": destination,
                "class": seat_class,
                "duration": duration,
                "stops": stops,
                "date": date
            }

            # Save ticket to session so /view_ticket shows the last generated ticket
            session['ticket'] = {
                "airline": airline or "Unknown",
                "source": source or "Unknown",
                "destination": destination or "Unknown",
                "travel_class": seat_class,
                "price": predicted_price,
                "passenger_name": session.get("user", "Guest"),
                "date": date or "",
                # keep time blank because you removed it from popup earlier
                "time": ""
            }

        except Exception as e:
            # catch form parsing errors
            tb = traceback.format_exc()
            app.logger.error("Error in /price: %s\n%s", e, tb)
            flash(f"Error processing request: {e}", "danger")

    return render_template("price.html",
                           predicted_price=predicted_price,
                           flight_info=flight_info,
                           datetime=datetime)


@app.route("/view_ticket")
def view_ticket():
    # show the latest ticket from session if available
    ticket = session.get("ticket")
    if not ticket:
        flash("No ticket found. Please predict first.", "warning")
        # fallback to a small placeholder so template doesn't break
        ticket = {
            "airline": "IndiGo",
            "source": "Delhi",
            "destination": "Mumbai",
            "travel_class": "Economy",
            "price": 4500,
            "passenger_name": "Guest",
            "date": datetime.now().strftime("%Y-%m-%d"),
            "time": ""
        }
    return render_template("ticket.html", **ticket)


if __name__ == "__main__":
    app.run(debug=True)
